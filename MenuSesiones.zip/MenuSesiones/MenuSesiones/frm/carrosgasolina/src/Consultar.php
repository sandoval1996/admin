 <?php
    ini_set("display_errors", "off");
	//Código para incluir las librerias
	 include_once("conexion.php");


	 //Conexión con el servidor
	  $link=ConectarseServidor();

	 //Conexión con la base de datos
	  ConectarseBaseDatos($link);

	 //realiza consulta a la base de datos
	 $sql = "select * from datosDiscoteca"; 
     
     $result=mysql_query($sql,$link);
	 
		while($row = mysql_fetch_array($result)){
			//$datos   = array('consola' => $row['consola'], 'valor' => $row['valor']);
			$datos   = array('codigo' => $row['codigo1'], 'nombre' => $row['nombre1'], 'telefono' => $row['telefono1'], 'descripciondelpedido' => $row['descripciondelpedido1'], 'cantiaddelpedido' => $row['cantidaddelpedido1'], 'fechadelpedido' => $row['fechadelpedido1'] ,'edad' => $row['edad1'], 'email' => $row['email1'],);
		    $rows[]     = $datos;


		}

	/*Función para desconectarse de la base de datos*/
	desconectarse($link);//cierra la conexion

    echo json_encode($rows);
 	
?>