 <?php
       ini_set("display_errors", "off");
       //Código para incluir las librerias
	   include_once("conexion.php");

	   //Conexión con el servidor
	   $link=ConectarseServidor();

	   //Conexión con la base de datos
	    ConectarseBaseDatos($link);

	  	
		//obtiene la informacion de las variables inmersas en el calculo del indice de masa corporal
	/*	$peso     		= $_POST["peso"];
		$estatura 		= $_POST["estatura"];
		$imc      		= $_POST["imc"];
		$clasificacion	= $_POST["clasificacion"];*/

		$codigo = $_POST["codigo"];
		$nombre = $_POST["nombre"];
		$telefono = $_POST["telefono"];
		$descripciondelpedido = $_POST["descripciondelpedido"];
		$cantidaddelpedido = $_POST["cantidaddelpedido"];
		$fechadelpedido = $_POST["fechadelpedido"];
		$edad = $_POST["edad"];
		$email = $_POST["email"];
		
		
		//construye cadena con sentencia sql
		$query = "insert into datosDiscoteca (codigo1, nombre1, telefono1,descripciondelpedido1,cantidaddelpedido1,fechadelpedido1 edad1,  email1, ) 
		VALUES ($codigo, '$nombre', $telefono, '$descripciondelpedido', $cantidaddelpedido, fechadelpedido, $edad,  '$email', )";
		
        /*Ejecución de la inserción*/
	     $respuesta=consultas($query);

    	/*Función para desconectarse de la base de datos*/
	    desconectarse($link);//cierra la conexion
 	
?>