<?php
     ini_set("display_errors", "off"); 
	//C�digo para incluir las librerias
	 include_once("conexion.php");
	 include('MyFPDF.php');

	 //Conexi�n con el servidor
	  $link=ConectarseServidor();

	 //Conexi�n con la base de datos
	  ConectarseBaseDatos($link);

	 //realiza consulta a la base de datos
	 $sql = "select * from datosDiscoteca"; 
     
     $result=mysql_query($sql,$link);

	   
	   //inclusi�n de rutinas para crear informes PDF
	   $pdf=new MyFPDF();
	   $pdf->AddPage('P');
	   $pdf->SetFont('Arial','B',11);
	   $pdf->Cell(0,8,"REGISTRO PEDIDOS DISCOTECA",0,0,'C',0);
	   $pdf->Cell(0,20,"",0,1,'',0);

		//titulos de las columnas
		$pdf->SetTextColor(0,0,0); //rgb
		$pdf->Cell(50,5,'codigo',1,0,'C');	
		$pdf->Cell(50,5,'nombre',1,0,'C');
		$pdf->Cell(50,5,'id',1,0,'C');
		$pdf->Cell(50,5,'telefono',1,0,'C');
		$pdf->Cell(50,5,'descripciondelpedido',1,0,'C');
		$pdf->Cell(50,5,'cantidaddelpedido',1,0,'C');
		$pdf->Cell(50,5,'fechadelpedido',1,0,'C');
		$pdf->Cell(50,5,'edad',1,0,'C');
		$pdf->Cell(50,5,'email',1,0,'C');	
		$pdf->SetFont('Arial','',10);

		//impresion de datos obtenidos desde la BD
		 while($row = mysql_fetch_array($result)){
			  $pdf->Cell(50,4,$row["id_datosDiscoteca"],1,0,'C');
			  $pdf->Cell(50,4,$row["codigo1"],1,0,'C');
			  $pdf->Cell(50,4,$row["nombre1"],1,0,'C');
			  $pdf->Cell(50,4,$row["telefono1"],1,0,'C');
			  $pdf->Cell(50,4,$row["descripciondelpedido1"],1,0,'C');
			  $pdf->Cell(50,4,$row["cantidaddelpedido1"],1,0,'C');
			  $pdf->Cell(50,4,$row["fechadelpedido1"],1,0,'C');
			  $pdf->Cell(50,4,$row["edad1"],1,0,'C');
			  $pdf->Cell(50,4,$row["email1"],1,1,'C');	
		  }//fin del while	
		
		 //libera memoria
		mysql_free_result ($result);

		//genera el PDF en el Navegador
		$pdf->Output();  
		//genera el PDF en un archivo
	    $pdf->Output("d:\ReporteIMC.pdf");  			 
?>