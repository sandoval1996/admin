//funcion para llamar proceso que genera reporte en pdf
function generarPDF(){
	
  //llama  la funcion que muestra el reporte en pdf
  parent.location="src/ReportePDF.php";
  
}//fin de la funcion generarPDF



