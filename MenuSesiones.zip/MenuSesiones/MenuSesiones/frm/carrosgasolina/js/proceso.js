	function guardar ()
		{

					var codigoA = $("#numCodigo").val();
					var nombreA = $("#txtNombre").val();
					var telefonoA = $("#numNombre").val();
					var descripciondepedidoA = $("#txtDescripcionP").val();
					var cantidaddepedidoA = $("#numCantidadP").val();
                    var fechapedidoA = $("#datFechaP").val();
					var edadA = $("#dateEdad").val();
					var emailA = $("#txtEmail").val();
			$.ajax
		({
			//construye la ruta donde se encuentra el archivo php
			url: "src/Guardar.php",
			//define las variables
			data: {
			//aqui guarda la informacion obtenida   --  consola(1): consola(2) (1) es el nombre de la clave inventada (2) es el valor obtenido por en el este java escrip ontenido anterior mente $(asa).val();
				


					codigo: codigoA,
					nombre: nombreA,
					telefono: telefonoA,
					descripciondepedido:descripciondepedidoA,
					cantidaddepedido: cantidaddepedidoA,
					fechapedido: fechapedidoA, 
					edad: edadA,
					email: emailA,				

			},
			type: "POST",
			context: document.body
		}).done(function( data ) 
		{		
			//llamado a metodo que obtiene datos
			obtenerDatos();
		});

		}

		function obtenerDatos()
		{
	
		//Consulta de Datos por medio de Formato JSON
		$.getJSON( "src/Consultar.php", function( data ) {
		
		//indica el sitio donde se mostrara la ubicacion en el formulario html
		$("#BodyTable").html("");
		
		//define arreglo
		var items = [];
				
		//realiza ciclo para recorrer por (llave, valor) y mostrar los registros		
		$.each( data, function( key, val ) {
		
			//adiciona los elementos 
			$("#BodyTable").append("<tr>\
										<th>" + val.valorIngresado + "</th>\
										<th>" + val.consola + "</th>\
									</tr>");
		});
	
	});

}


	