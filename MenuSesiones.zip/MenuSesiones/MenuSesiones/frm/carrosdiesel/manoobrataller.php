 <!DOCTYPE html>
<html>
    <head>
        <title>taller mecanica</title>
        <script src="js/jquery/jquery-3.1.0.js"> </script>
        <script src="js/proceso.js"></script> 
        <script src="js/reporte.js"></script>
	    <link rel="stylesheet" href="css/estilosCambio.css">
    </head>
    <body>
        <!-- En esta seccion se procede a colocar el Encabezado de la pagina-->
        <div class="Titulo">
        <center><h1><p id="texto">TALLER MECANICA</p></h1></center></div>
         
        <center><img src="img/motordiesel.jpg" width="300" height="250" BORDER=2 ALT="motordiesel"></center>

        <fieldset class="formulario">
		<form id="tallermecanica" method="post">

	       <center>Cedula:</center>
	       <center><input type="text" id="txtCedula"  required></center>
	       <br>
	       <center>Nombres:</center>
	       <center><input type="text" id="txtNombres" required></center>
	       <br>
	       <center>Apellidos:</center>
	       <center><input type="text" id="txtApellidos" required></center>
	       <br>
	       <center>marcavehiculo:</center>
	       <center><input type="text" id="txtmarcaVehiculo" required></center>
	       <br>
	      
        <center>Descripcion mecanica:</center>
        <center><textarea id="txtdescripcionmecanica" placeholder="Introduzca toda la informacion de la mano de obra del vehiculo" rows="10" cols="40"></textarea></center>
       
	       <br>
	       <center>valor (mano obra,repuestos):</center>
	       <center><input type="number" id="nummanodeobra" required></center>
	       <br>
	       <center>fecha:</center>
	       <center><input type="date" id="datfecha" required></center>
           <br>
		</form>
		</fieldset>

           <br>
		<center>
           <button type="submit" form="tallermecanica" id="btnGuardarValidadar" value="Submit">Validar</button>
		   <input type="button" id="btnEnviarBaseDeDatos" value="Registrar Informacion">
		   <input type="button" id="btnGenerarReportePDFTotal" value="Generar Reporte PDF" onClick="generarPDFT()">
	        </center>
        <br>
        <br>
        <br>
        <div class="Titulo">
        <center><h1><p id="texto">Filtro Busqueda (PDF)</p></h1></center></div>
        <fieldset class="formulario">
		<form name="formFiltrotallermecanica" id="femFiltrotallermecanica" method="post">

	       <center>Cedula de la persona:</center>
	       <center><input type="text" id="txtCedulaF" name="txtCedulaF"  required></center>
	       <br>
		</form>
		</fieldset>

           <br>
		<center>
           <button type="submit" form="formFiltrotallermecanica" id="btnGuardarValidadarFiltro" value="Submit">Validar</button>
		   <input type="button" id="btnGenerarReportePDFFiltro" value="Generar Reporte PDF (FIltro)" onClick="generarPDFFiltro()">
	    </center>
    </body>

</html>