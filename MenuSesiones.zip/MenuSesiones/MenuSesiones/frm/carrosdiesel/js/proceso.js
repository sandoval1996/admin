$( document ).ready(function(){
 
    //valida el boton para generar las acciones del evento
	$("#btnEnviarBaseDeDatos").click(function(){
	
	   //obtiene la informacion de la caja de texto de peso
    	cedula = $("#txtCedula").val();
    	nombres = $("#txtNombres").val();
    	apellios = $("#txtApellidos").val();
    	marcaVehiculo = $("#txtmarcaVehiculo").val();
    	 descripcionmecanica = $("#txtDescripcionmecanica").val();
    	valormanodeobra = $("#nummanodeobra").val();
    	fecha = $("#datfecha").val();
	
		//proceso para enviar datos a php por medio de ajax
		//las variables son capturadas con JSON (  key:value)
        //donde key es la variable definida y debe ser igual a la que reciba el servidor php y value es la variable local)  
		
		$.ajax({
			//construye la ruta donde se encuentra el archivo php
			url: "src/guardar.php",
			//define las variables
			data: {
					cedula: cedula,
					nombres: nombres,
					apellios: apellios,
					marcaVehiculo: marcaVehiculo,
					descripcionmecanica: descripcionmecanica,
					valormanodeobra: valormanodeobra,
					fecha: fecha
			},
			type: "POST",
			context: document.body
		})
		alert("La informacion ha sido registrada"); 
	});

});

