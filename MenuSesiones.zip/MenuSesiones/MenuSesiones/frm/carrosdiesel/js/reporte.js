//funcion para llamar proceso que genera reporte en pdf
function generarPDFT(){
	
  //llama  la funcion que muestra el reporte en pdf
  parent.location="src/reportePDF.php";
  
}//fin de la funcion generarPDF

//funcion para llamar proceso que genera reporte en pdf
function generarPDFFiltro(){
	
 
  cedulaFiltro = $("#txtCedulaF").val();

    
        //proceso para enviar datos a php por medio de ajax
		//las variables son capturadas con JSON (  key:value)
        //donde key es la variable definida y debe ser igual a la que reciba el servidor php y value es la variable local)  
		/*
		$.ajax({
			//construye la ruta donde se encuentra el archivo php
			url: "src/guardarConsulta.php",
			//define las variables
			data: {
					cedulaFiltro: cedulaFiltro
			},
			type: "POST",
			context: document.body
		})


   alert("pdf :) " + cedulaFiltro)
  //llama  la funcion que muestra el reporte en pdf
  parent.location="src/filtroPDF.php";
 */
 
  window.open("src/filtroPDF.php?cedulaF=" + cedulaFiltro);
 
  
}//fin de la funcion generarPDF



