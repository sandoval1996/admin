 <?php
       ini_set("display_errors", "off");
       //Código para incluir las librerias
	   include_once("conexion.php");

	   //Conexión con el servidor
	   $link=ConectarseServidor();

	   //Conexión con la base de datos
	    ConectarseBaseDatos($link);

	  	
		//obtiene la informacion de las variables inmersas en el calculo del indice de masa corporal
		$cedula     		= $_POST["cedula"];
		$nombres 		    = $_POST["nombres"];
		$apellios      		= $_POST["apellios"];
		$marcavehiculo   = $_POST["marcavehiculo"];
		$descripcionmecanica     = $_POST["descripcionmecanica"];
		$valor    		= $_POST["valor"];
		$fecha     		= $_POST["fecha"];
		
		//construye cadena con sentencia sql
		$query = "INSERT into datostaller (cedula, nombres, apellidos, marcavehiculo, descripcionmecanica, valor, fecha) VALUES ('$cedula', '$nombres', '$apellios', '$marcavehiculo', '$descripcionmecanica', $valor, '$fecha')";
		
        /*Ejecución de la inserción*/
	     $respuesta=consultas($query);

    	/*Función para desconectarse de la base de datos*/
	    desconectarse($link);//cierra la conexion
 	
?>